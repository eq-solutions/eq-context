# Files to DELETE from eq-context repo

The following files should be **removed** from the repo (git rm + commit),
not overwritten. They are duplicates or obsolete.

---

## 1. `sessions/sessions_2026-04-15.md`

**Reason:** Duplicate of `sessions/2026-04-15.md` — same content, non-standard filename.
The `sessions/2026-04-15.md` version (ISO date filename) is canonical.

**Risk if not deleted:** The GitHub Action in `.github/workflows/sync-context.yml`
globs `sessions/*.md` and upserts each file with its path as the `slug`. This means
the duplicate will sync to Supabase as a second row (`slug: sessions/sessions_2026-04-15.md`)
alongside the real one (`slug: sessions/2026-04-15.md`), polluting the context store.

**How to delete:**
```bash
git rm sessions/sessions_2026-04-15.md
git commit -m "chore(context): remove duplicate 2026-04-15 session log"
git push origin main
```

Also clean up the orphaned Supabase row after the Action next runs — it won't delete
the old `sessions/sessions_2026-04-15.md` slug automatically:

```sql
-- Run against urjhmkhbgaxrofurpbgc (eq-solves-service-dev)
DELETE FROM context_files WHERE slug = 'sessions/sessions_2026-04-15.md';
```

---

## Optional cleanup (future hardening)

The sync-context Action is upsert-only — it never deletes rows when files are removed
from the repo. Over time, deleted files leave orphaned rows in Supabase. Consider
adding a reconciliation step that lists all slugs currently in `context_files` and
deletes any that no longer exist in the repo. Out of scope for this patch.
